		
			<footer class="site-footer">
				<span>
					<?php echo __('All right reserved','naiau'); ?>
				</span>
				<?php wp_footer(); ?>
			</footer>
		</div>
	</body>
</html>